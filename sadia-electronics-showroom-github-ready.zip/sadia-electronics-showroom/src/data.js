export const shop = {
  name: "সাদিয়া ইলেকট্রনিক্স",
  tagline: "আপনার ঘরের জন্য আধুনিক প্রযুক্তির বিশ্বস্ত ঠিকানা",
  phone: import.meta.env.VITE_SHOP_PHONE || "8801XXXXXXXXX",
  whatsapp: import.meta.env.VITE_SHOP_WHATSAPP || "8801XXXXXXXXX",
  address: "আপনার শোরুমের ঠিকানা এখানে লিখুন",
  hours: "প্রতিদিন সকাল ৯টা — রাত ৯টা",
  facebook: "https://www.facebook.com/",
  mapUrl: "https://www.google.com/maps"
};

export const categories = [
  { id: "tv", name: "টেলিভিশন", icon: "Tv" },
  { id: "refrigerator", name: "ফ্রিজ", icon: "Refrigerator" },
  { id: "ac", name: "এসি", icon: "Wind" },
  { id: "washing", name: "ওয়াশিং মেশিন", icon: "WashingMachine" },
  { id: "fan", name: "ফ্যান", icon: "Fan" },
  { id: "microwave", name: "মাইক্রোওভেন", icon: "Microwave" }
];

export const products = [
  {
    id: "tv-1",
    category: "tv",
    badge: "জনপ্রিয়",
    name: "Smart 4K LED TV",
    subtitle: "4K UHD • Smart TV • HDR",
    price: "দাম জানতে যোগাযোগ করুন",
    image: "https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "fridge-1",
    category: "refrigerator",
    badge: "নতুন",
    name: "Inverter Refrigerator",
    subtitle: "Energy Saving • Spacious",
    price: "দাম জানতে যোগাযোগ করুন",
    image: "https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "ac-1",
    category: "ac",
    badge: "সাশ্রয়ী",
    name: "Inverter Air Conditioner",
    subtitle: "Fast Cooling • Energy Efficient",
    price: "দাম জানতে যোগাযোগ করুন",
    image: "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "washing-1",
    category: "washing",
    badge: "জনপ্রিয়",
    name: "Front Load Washing Machine",
    subtitle: "Multiple Wash Programs",
    price: "দাম জানতে যোগাযোগ করুন",
    image: "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "fan-1",
    category: "fan",
    badge: "অফার",
    name: "Premium Ceiling Fan",
    subtitle: "High Airflow • Low Noise",
    price: "দাম জানতে যোগাযোগ করুন",
    image: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=900&q=80"
  },
  {
    id: "micro-1",
    category: "microwave",
    badge: "নতুন",
    name: "Digital Microwave Oven",
    subtitle: "Quick Cook • Easy Control",
    price: "দাম জানতে যোগাযোগ করুন",
    image: "https://images.unsplash.com/photo-1585659722983-3a675dabf23d?auto=format&fit=crop&w=900&q=80"
  }
];

/*
  YouTube links:
  Replace only the `url` values below.
  Example:
  https://www.youtube.com/watch?v=dQw4w9WgXcQ
*/
export const videos = [
  {
    id: "video-1",
    title: "সাদিয়া ইলেকট্রনিক্স — আমাদের শোরুম",
    description: "শোরুম ও নতুন পণ্যের সংক্ষিপ্ত ভিডিও",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  },
  {
    id: "video-2",
    title: "নতুন পণ্যের আনবক্সিং",
    description: "নতুন electronics collection দেখুন",
    url: "https://www.youtube.com/watch?v=ScMzIvxBSi4"
  },
  {
    id: "video-3",
    title: "কেন সাদিয়া ইলেকট্রনিক্স?",
    description: "পণ্য, সার্ভিস ও আমাদের প্রতিশ্রুতি",
    url: "https://www.youtube.com/watch?v=ysz5S6PUM-U"
  }
];