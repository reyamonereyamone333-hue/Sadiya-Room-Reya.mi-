import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowRight, CheckCircle2, ChevronDown, Facebook, Fan, Flame,
  Headphones, MapPin, Menu, MessageCircle, Microwave, Phone,
  Refrigerator, Search, ShieldCheck, ShoppingBag, Sparkles, Tv,
  WashingMachine, Wind, X, Youtube, Zap
} from "lucide-react";
import { categories, products, shop, videos } from "./data";
import "./styles.css";

const iconMap = { Tv, Refrigerator, Wind, WashingMachine, Fan, Microwave };

function safeYouTubeId(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    if (host === "youtube.com" || host === "m.youtube.com") {
      if (url.pathname === "/watch") return url.searchParams.get("v");
      if (url.pathname.startsWith("/shorts/")) return url.pathname.split("/")[2];
      if (url.pathname.startsWith("/embed/")) return url.pathname.split("/")[2];
    }
    if (host === "youtu.be") return url.pathname.split("/")[1];
  } catch {
    return null;
  }
  return null;
}

function youtubeEmbed(url) {
  const id = safeYouTubeId(url);
  return id ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?rel=0` : null;
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState("all");
  const [query, setQuery] = useState("");

  const filteredProducts = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      const categoryMatch = activeCategory === "all" || p.category === activeCategory;
      const textMatch = !q || `${p.name} ${p.subtitle}`.toLowerCase().includes(q);
      return categoryMatch && textMatch;
    });
  }, [activeCategory, query]);

  const whatsappUrl = `https://wa.me/${encodeURIComponent(shop.whatsapp.replace(/[^0-9]/g, ""))}?text=${encodeURIComponent("সাদিয়া ইলেকট্রনিক্সের পণ্য সম্পর্কে জানতে চাই।")}`;

  return (
    <div>
      <header className="header">
        <a className="brand" href="#home" aria-label="সাদিয়া ইলেকট্রনিক্স হোম">
          <span className="brand-mark"><Zap size={21} fill="currentColor" /></span>
          <span><strong>সাদিয়া</strong><small>ELECTRONICS</small></span>
        </a>

        <nav className={`nav ${menuOpen ? "open" : ""}`}>
          <a href="#home" onClick={() => setMenuOpen(false)}>হোম</a>
          <a href="#products" onClick={() => setMenuOpen(false)}>পণ্যসমূহ</a>
          <a href="#videos" onClick={() => setMenuOpen(false)}>ভিডিও</a>
          <a href="#services" onClick={() => setMenuOpen(false)}>সার্ভিস</a>
          <a href="#contact" onClick={() => setMenuOpen(false)}>যোগাযোগ</a>
        </nav>

        <div className="header-actions">
          <a className="icon-btn" href="#products" aria-label="পণ্য খুঁজুন"><Search size={19}/></a>
          <a className="top-cta" href={whatsappUrl} target="_blank" rel="noopener noreferrer">
            <MessageCircle size={17}/> WhatsApp
          </a>
          <button className="menu-btn" onClick={() => setMenuOpen(v => !v)} aria-label="মেনু">
            {menuOpen ? <X/> : <Menu/>}
          </button>
        </div>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="hero-grid">
            <div className="hero-copy">
              <div className="eyebrow"><Sparkles size={15}/> Trusted Electronics Showroom</div>
              <h1>আপনার ঘরের জন্য<br/><span>সেরা প্রযুক্তি</span></h1>
              <p>{shop.tagline}. ভালো পণ্য, পরিষ্কার তথ্য এবং বিশ্বস্ত সার্ভিস—সব এক জায়গায়।</p>
              <div className="hero-buttons">
                <a className="primary-btn" href="#products">পণ্য দেখুন <ArrowRight size={18}/></a>
                <a className="secondary-btn" href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                  <MessageCircle size={18}/> অর্ডার/জানুন
                </a>
              </div>
              <div className="trust-row">
                <span><ShieldCheck size={18}/> বিশ্বস্ত পণ্য</span>
                <span><CheckCircle2 size={18}/> বিক্রয়োত্তর সহায়তা</span>
              </div>
            </div>
            <div className="hero-showcase" aria-label="Featured electronics">
              <div className="glow"></div>
              <div className="showcase-tv">
                <div className="screen"><span>4K</span><b>SMART</b></div>
              </div>
              <div className="showcase-fridge"></div>
              <div className="floating-card card-one"><Zap size={18}/><div><b>Energy Efficient</b><small>বিদ্যুৎ সাশ্রয়ী প্রযুক্তি</small></div></div>
              <div className="floating-card card-two"><Headphones size={18}/><div><b>Customer Care</b><small>সহজে যোগাযোগ করুন</small></div></div>
            </div>
          </div>
          <div className="hero-bottom">
            {categories.slice(0, 4).map((c) => {
              const Icon = iconMap[c.icon];
              return <a key={c.id} href="#products" onClick={() => setActiveCategory(c.id)}><Icon size={22}/><span>{c.name}</span><ArrowRight size={15}/></a>
            })}
          </div>
        </section>

        <section className="section category-strip">
          <div className="section-head">
            <div><span className="kicker">EXPLORE</span><h2>জনপ্রিয় ক্যাটাগরি</h2></div>
            <a href="#products">সব পণ্য <ArrowRight size={16}/></a>
          </div>
          <div className="category-grid">
            {categories.map((c) => {
              const Icon = iconMap[c.icon];
              return <button key={c.id} className={`category-card ${activeCategory === c.id ? "active" : ""}`} onClick={() => {setActiveCategory(c.id); document.querySelector("#products")?.scrollIntoView({behavior:"smooth"});}}>
                <span className="category-icon"><Icon size={26}/></span><b>{c.name}</b><small>দেখুন <ArrowRight size={13}/></small>
              </button>
            })}
          </div>
        </section>

        <section id="products" className="section products-section">
          <div className="section-head product-head">
            <div><span className="kicker">OUR COLLECTION</span><h2>নির্বাচিত পণ্য</h2><p>আপনার প্রয়োজন অনুযায়ী পছন্দ করুন</p></div>
            <div className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value.slice(0, 80))} placeholder="পণ্য খুঁজুন..." aria-label="পণ্য খুঁজুন"/></div>
          </div>
          <div className="filter-row">
            <button className={activeCategory === "all" ? "selected" : ""} onClick={() => setActiveCategory("all")}>সব</button>
            {categories.map(c => <button key={c.id} className={activeCategory === c.id ? "selected" : ""} onClick={() => setActiveCategory(c.id)}>{c.name}</button>)}
          </div>
          <div className="product-grid">
            {filteredProducts.map(p => (
              <article className="product-card" key={p.id}>
                <div className="product-image">
                  <img src={p.image} alt={p.name} loading="lazy" referrerPolicy="no-referrer"/>
                  <span>{p.badge}</span>
                </div>
                <div className="product-info">
                  <small>{categories.find(c => c.id === p.category)?.name}</small>
                  <h3>{p.name}</h3><p>{p.subtitle}</p>
                  <div className="product-bottom"><b>{p.price}</b><a href={whatsappUrl} target="_blank" rel="noopener noreferrer" aria-label={`${p.name} সম্পর্কে যোগাযোগ`}>জানুন <ArrowRight size={15}/></a></div>
                </div>
              </article>
            ))}
          </div>
          {filteredProducts.length === 0 && <div className="empty">কোনো পণ্য পাওয়া যায়নি। অন্য নামে চেষ্টা করুন।</div>}
        </section>

        <section id="videos" className="section video-section">
          <div className="section-head"><div><span className="kicker">WATCH & DISCOVER</span><h2>YouTube ভিডিও</h2><p>আপনার ভিডিও লিংক `src/data.js` থেকে সহজেই পরিবর্তন করতে পারবেন।</p></div><a className="youtube-link" href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer"><Youtube size={17}/> YouTube</a></div>
          <div className="video-grid">
            {videos.map(v => {
              const embed = youtubeEmbed(v.url);
              return <article className="video-card" key={v.id}>
                <div className="video-frame">
                  {embed ? <iframe src={embed} title={v.title} loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen referrerPolicy="strict-origin-when-cross-origin"/> : <div className="video-error">Invalid YouTube URL</div>}
                </div>
                <div className="video-info"><span>VIDEO</span><h3>{v.title}</h3><p>{v.description}</p></div>
              </article>
            })}
          </div>
        </section>

        <section id="services" className="section services-section">
          <div className="service-intro"><span className="kicker">WHY SADIA</span><h2>কেন আমাদের বেছে নেবেন?</h2><p>শুধু পণ্য নয়—কেনার আগে সঠিক তথ্য এবং কেনার পর সহযোগিতাকে আমরা গুরুত্ব দিই।</p></div>
          <div className="service-grid">
            <div><ShieldCheck/><h3>বিশ্বস্ত পণ্য</h3><p>নির্বাচিত electronics ও পরিষ্কার product information.</p></div>
            <div><Headphones/><h3>Customer Support</h3><p>প্রয়োজনে দ্রুত যোগাযোগ ও সহযোগিতা।</p></div>
            <div><Zap/><h3>সহজ অর্ডার</h3><p>ফোন বা WhatsApp-এ পণ্যের তথ্য ও অর্ডার জানতে পারবেন।</p></div>
            <div><ShoppingBag/><h3>শোরুম অভিজ্ঞতা</h3><p>শোরুমে এসে পণ্য সম্পর্কে সরাসরি জানুন।</p></div>
          </div>
        </section>

        <section className="offer">
          <div><span className="kicker">SPECIAL OFFER</span><h2>আপনার পছন্দের পণ্যটি খুঁজছেন?</h2><p>মডেল বা পণ্যের নাম পাঠান—মূল্য ও availability জানতে যোগাযোগ করুন।</p></div>
          <a className="primary-btn light" href={whatsappUrl} target="_blank" rel="noopener noreferrer"><MessageCircle size={18}/> WhatsApp করুন</a>
        </section>

        <section id="contact" className="section contact-section">
          <div className="contact-card">
            <div><span className="kicker">CONTACT</span><h2>সাদিয়া ইলেকট্রনিক্স</h2><p>{shop.tagline}</p></div>
            <div className="contact-items">
              <a href={`tel:+${shop.phone.replace(/[^0-9]/g,"")}`}><Phone/><span><small>ফোন</small><b>{shop.phone}</b></span></a>
              <a href={shop.mapUrl} target="_blank" rel="noopener noreferrer"><MapPin/><span><small>ঠিকানা</small><b>{shop.address}</b></span></a>
              <div><Flame/><span><small>খোলার সময়</small><b>{shop.hours}</b></span></div>
            </div>
            <div className="contact-actions"><a className="primary-btn" href={whatsappUrl} target="_blank" rel="noopener noreferrer"><MessageCircle size={18}/> WhatsApp</a><a className="secondary-btn dark" href={shop.facebook} target="_blank" rel="noopener noreferrer"><Facebook size={18}/> Facebook</a></div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div><a className="brand footer-brand" href="#home"><span className="brand-mark"><Zap size={19}/></span><span><strong>সাদিয়া</strong><small>ELECTRONICS</small></span></a><p>আধুনিক প্রযুক্তি, বিশ্বস্ত সেবা।</p></div>
        <div className="footer-links"><a href="#products">পণ্য</a><a href="#videos">ভিডিও</a><a href="#services">সার্ভিস</a><a href="#contact">যোগাযোগ</a></div>
        <small>© {new Date().getFullYear()} Sadia Electronics. All rights reserved.</small>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);