# সাদিয়া ইলেকট্রনিক্স শোরুম

GitHub-ready, responsive React + Vite showroom website.

## Features

- Premium electronics showroom UI
- Responsive mobile/tablet/desktop design
- Product categories and featured products
- YouTube video section — শুধু `src/data.js`-এ YouTube URL বদলালেই হবে
- Product search and category filtering
- WhatsApp/order CTA
- Contact/location section
- Accessible buttons, keyboard-friendly navigation
- No secrets in source code
- External links use safe `noopener noreferrer`
- Client-side input handling avoids injecting HTML
- Production build configuration

## Run locally

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
npm run preview
```

## YouTube video পরিবর্তন

`src/data.js` খুলে `videos` array-তে:

```js
{
  id: "video-1",
  title: "আমাদের নতুন পণ্য",
  url: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID"
}
```

নিজের YouTube link দিন। YouTube ID parser কেবল YouTube/YouTube Shorts/YouTube embed URL গ্রহণ করে।

## দোকানের তথ্য পরিবর্তন

`src/data.js`-এর `shop` object পরিবর্তন করুন।

## GitHub Pages

Vite project-টি GitHub-এ push করে GitHub Actions দিয়ে deploy করা যায়। চাইলে পরে custom domain-ও যুক্ত করতে পারবেন।

## Security note

এটি একটি frontend-only showroom site। কোনো frontend application-কে সম্পূর্ণ "unhackable" বলা যায় না। এখানে private credentials রাখা হয়নি এবং external YouTube URL allowlist করা হয়েছে। ভবিষ্যতে login, admin panel, orders, customer accounts বা payments যোগ করলে server-side authentication, authorization, validation, CSRF protection, rate limiting, secure sessions এবং database security আলাদাভাবে implement করতে হবে।